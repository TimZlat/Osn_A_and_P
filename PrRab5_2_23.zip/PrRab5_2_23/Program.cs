﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrRab5_2_23
//суммирование бесконечного ряда пр. раб.5 задача 2 вар.23
{
    class Program
    {
        static void Main(string[] args)
        {
            double x, y, sum, a, p1, p2;
            int n, k;
            bool f = true;
            while (f)
            {
                Console.Write("Введите значение х: ");
                x = double.Parse(Console.ReadLine());
                k = 0;
                sum = 0;
                n = 0;
                a = x;
                while (Math.Abs(a) >= 0.000001)
                {
                    sum += a;
                    p1 = (double)1 / (2 * n + 1);
                    p2 = Math.Pow((x - 1) / (x + 1), (2 * n + 1));
                    a = p1 * p2;
                    n += 1;
                    k++;
                    Console.WriteLine("\tИтерация " + k + '\n' + " a= " + a + " sum= " + sum + '\n');
                }
                y = 0.5 * Math.Log(x);
                Console.WriteLine('\t' + "РЕЗУЛЬТАТЫ:" + '\n'+"значение х=" + x + '\n' + "Сумма ряда: " + sum + " количество слагаемых ряда: " + k + '\n' + " значение искомой функции=" + y + '\n');
                Console.WriteLine("Продолжить работу? y/n");
                string otv = Console.ReadLine();
                if (otv == "n") f = false;
            }
            Console.WriteLine("Для завершения работы нажмите любую клавишу...");
            Console.ReadKey();
        }
    }
}
