﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonsterClass
{
    class Program
    {
        class Monster
        {
            string name;// закрытые поля класса
            int health;
            int amno;

            public Monster() //Конструкторы класса
            {
                this.name = "Noname";
                this.health = 100;
                this.amno = 100;
            }
            public Monster(string name)
                : this()
            {
                this.name = name;
            }
            public Monster(int health, int amno, string name)
            {
                this.name = name;
                this.health = health;
                this.amno = amno;
            }
            public string GetName() //Метод получить имя
            {
                return name;
            }
            public int GetHealht() //метод получить значение здоровья
            {
                return health;
            }
            public int GetAmno() // метод получить кол-во ног
            {
                return amno;
            }
            public void Passport() // метод вывода паспорта монстра
            {
                Console.WriteLine("Monster {0} \t health = {1} amno = {2}",
                    name, health, amno);
            }

            public int Health // свойство Health связано с полем Health
            {
                get { return health; }
                set
                {
                    if (value > 0) health = value;
                    else health = 0;
                }
            }
            public int Amno
            {
                get { return amno; }
                set
                {
                    if (value > 0) amno = value;
                    else amno = 0;
                }
            }
            public string Name
            {
                get { return name; }
            }
            //ОПЕРАЦИИ
            //Унарные
            public static Monster operator ++(Monster m)
            {
                Monster tmp = new Monster();
                tmp.health = m.health + 1;
                tmp.name = m.name;
                tmp.amno = m.amno + 1;
                return tmp;

            }
            public static Monster operator --(Monster m)
            {
                Monster tmp = new Monster();
                tmp.health = m.health - 1;
                tmp.name = m.name;
                tmp.amno = m.amno - 1;
                return tmp;
            }

        }

        static void Main()
        {
            Monster X = new Monster();
            X.Passport();

            Monster Vasia = new Monster("Вася");
            Vasia.Passport();

            Monster Masha = new Monster(200, 200, "Маруся");
            Masha.Passport();
           // использование свойств
            Console.WriteLine(" \nУ монстра {0} изменили кое-что", Masha.Name);
            --Masha.Health;
            Masha.Amno += 100;
            Masha.Passport();
           
            //проверка операций
            Console.WriteLine("\n\n Проверка добавленных в класс операций ");
            Monster Goga = new Monster(70, 50, "Гога");
            Goga.Passport();
            Goga++;
            Goga.Passport();
            Goga--;
            Goga.Passport();
            
            Console.ReadKey();
        }
    }
}
