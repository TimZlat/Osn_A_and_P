﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MonsterClass
{
    class Program
    {
        class Monster
        {
            string name;// закрытые поля класса
            int health;
            int amno;

            public Monster() //Конструкторы класса
            {
                this.name = "Noname";
                this.health = 100;
                this.amno = 100;
            }
            public Monster(string name)
                : this()
            {
                this.name = name;
            }
            public Monster(int health, int amno, string name)
            {
                this.name = name;
                this.health = health;
                this.amno = amno;
            }
            public string GetName() //Метод получить имя
            {
                return name;
            }
            public int GetHealht() //метод получить значение здоровья
            {
                return health;
            }
            public int GetAmno() // метод получить кол-во ног
            {
                return amno;
            }
            

            public int Health // свойство Health связано с полем Health
            {
                get { return health; }
                set
                {
                    if (value > 0) health = value;
                    else health = 0;
                }
            }
            public int Amno //свойство Amno связано с полем amno
            {
                get { return amno; }
                set
                {
                    if (value > 0) amno = value;
                    else amno = 0;
                }
            }
            public string Name //свойство Name доступно только для чтения
            {
                get { return name; }
            }
            //ОПЕРАЦИИ
            //Унарные
            public static Monster operator ++(Monster m)
            {
                Monster tmp = new Monster();
                tmp.health = m.health + 1;
                tmp.name = m.name;
                tmp.amno = m.amno + 1;
                return tmp;

            }
            public static Monster operator --(Monster m)
            {
                Monster tmp = new Monster();
                tmp.health = m.health - 1;
                tmp.name = m.name;
                tmp.amno = m.amno - 1;
                return tmp;
            }
            //Бинарные операции
            public static Monster operator + (Monster m,int k)
            {
                Monster temp = new Monster(m.name);
                temp.health = m.health - 1;
                return temp;
            }
            public static Monster operator +(int k,Monster m)
            {
                Monster temp = new Monster(m.name);
                temp.amno = m.amno + k;
                return temp;
            }
            //операторы преобразования типов
            public static implicit operator int(Monster m)
            {
                return m.health;
            }
            public static explicit operator Monster(int h)
            {
                return new Monster(h, 100, "FromInt;");
            }
            //МЕТОДЫ
            public string GetState()
                //узнать состояние монстра
            {
                if (health >= 90) return "Здоров как бык";
                if (health >= 70) return "Легко ранен";
                if (health >= 50) return "Ранение средней тяжести";
                if (health >= 30) return "Тяжелое ранение";
                if (health >= 0) return "Смертельное ранение";
                if (health > 0) return "Пал смертью храбрых";
                else return " Умер по непонятной причине";
            }
            public void Passport() // метод вывода паспорта монстра
            {
                Console.WriteLine("У монстра {0} \t Здоровье = {1} Оружие = {2} " +
                    " Состояние: {3}", name, health, amno, GetState());
            }
            public void Passport(string m)
            {
                //перегруженная функция Паспортные данные
                Console.WriteLine("У {4} {0} \t Здоровье={1} Оружие={2}" +
                    " Состояние: {3}", name, health, amno, GetState(), m);
            }
            public void Passport(int k, string m)
            {
                //Другая перегруженная функция Паспортные данные
                for (int i = 0; i < k; i++)
                    Console.WriteLine("У {4} {0} \t Здоровье={1} Оружие={2}" +
                    " Состояние: {3}", name, health, amno, GetState(), m);
            }

        }

        static void Main()
        {
            Monster X = new Monster();
            X.Passport();

            Monster Vasia = new Monster("Вася");
            Vasia.Passport();

            Monster Masha = new Monster(200, 200, "Маруся");
            Masha.Passport();
           // использование свойств
            Console.WriteLine(" \nУ монстра {0} изменили кое-что", Masha.Name);
            --Masha.Health;
            Masha.Amno += 100;
            Masha.Passport();
           
            //проверка операций
            Console.WriteLine("\n\n Проверка добавленных в класс операций ");
            Monster Goga = new Monster(70, 50, "Гога");
            Goga.Passport();
            Goga++;
            Goga.Passport();
            Goga--;
            Goga.Passport();
            
            Console.ReadKey();
        }
    }
}
